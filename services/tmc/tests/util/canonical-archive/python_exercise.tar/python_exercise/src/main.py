print("main")
